### <p align="center">ѧϰ�����вο���ʹ�õĴ���</p>
### <p align="center">Code referenced or used during the learning process</p>

------

> * [Mile.Xaml.Samples](https://github.com/ProjectMile/Mile.Xaml.Samples)&emsp;
> * [NanaBox](https://github.com/M2Team/NanaBox/)&emsp;