#include "ConfigKey.h"

const winrt::hstring ConfigKey::AlwaysShowBackdropKey = L"AlwaysShowBackdrop";
const winrt::hstring ConfigKey::ThemeKey = L"AppTheme";