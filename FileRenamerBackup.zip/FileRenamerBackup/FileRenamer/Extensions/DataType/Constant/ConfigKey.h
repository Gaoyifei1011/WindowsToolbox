#pragma once

#include <winrt/base.h>

namespace winrt
{
}

class ConfigKey
{
public:
	static const winrt::hstring AlwaysShowBackdropKey;
	static const winrt::hstring ThemeKey;
};
