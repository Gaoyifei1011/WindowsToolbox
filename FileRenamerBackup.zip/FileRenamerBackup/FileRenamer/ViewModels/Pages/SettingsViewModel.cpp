﻿#pragma once

#include "pch.h"
#include "SettingsViewModel.h"
#include "SettingsViewModel.g.cpp"

namespace winrt::FileRenamer::implementation
{
	SettingsViewModel::SettingsViewModel()
	{
		_themeList = AppThemeService.ThemeList();

		_restartCommand = winrt::make<winrt::FileRenamer::implementation::RelayCommand>([this](winrt::WinrtFoundation::IInspectable parameter) -> WinrtFoundation::IAsyncAction
			{
				FileRenamer::RestartAppsDialog dialog;
				dialog.XamlRoot(MileWindow::Current()->Content().XamlRoot());
				co_await dialog.ShowAsync();
			});

		_settingsColorCommand = winrt::make<winrt::FileRenamer::implementation::RelayCommand>([this](winrt::WinrtFoundation::IInspectable parameter) -> winrt::WinrtFoundation::IAsyncAction
			{
				winrt::WinrtFoundation::Uri uri(L"ms-settings:colors");
				co_await winrt::WinrtSystem::Launcher::LaunchUriAsync(uri);
			});

		_themeSelectCommand = winrt::make<winrt::FileRenamer::implementation::RelayCommand>([this](winrt::WinrtFoundation::IInspectable themeIndex)
			{
				SettingsViewModel::Theme(SettingsViewModel::ThemeList().GetAt(winrt::unbox_value<uint32_t>(themeIndex)));
				AppThemeService.SetTheme(SettingsViewModel::Theme());
				AppThemeService.SetWindowTheme();
			});
	};

	winrt::FileRenamer::ThemeModel SettingsViewModel::Theme()
	{
		return _theme;
	}
	void SettingsViewModel::Theme(winrt::FileRenamer::ThemeModel const& value)
	{
		_theme = value;
	}

	/// <summary>
	/// 打开重启应用确认的窗口对话框
	/// </summary>
	winrt::WinrtInput::ICommand SettingsViewModel::RestartCommand()
	{
		return _restartCommand;
	}

	/// <summary>
	/// 打开系统主题设置
	/// </summary>
	winrt::WinrtInput::ICommand SettingsViewModel::SettingsColorCommand()
	{
		return _settingsColorCommand;
	}

	/// <summary>
	/// 主题修改设置
	/// </summary>
	winrt::WinrtInput::ICommand SettingsViewModel::ThemeSelectCommand()
	{
		return _themeSelectCommand;
	}

	winrt::WinrtCollections::IObservableVector<winrt::FileRenamer::ThemeModel> SettingsViewModel::ThemeList()
	{
		return _themeList;
	}

	void SettingsViewModel::OnSelectionChanged(winrt::WinrtFoundation::IInspectable const& sender, winrt::WinrtControls::SelectionChangedEventArgs args)
	{
		if (args.RemovedItems().Size() > 0)
		{
			SettingsViewModel::Theme(args.AddedItems().GetAt(0).try_as<winrt::FileRenamer::ThemeModel>());
			AppThemeService.SetTheme(SettingsViewModel::Theme());
			AppThemeService.SetWindowTheme();
		}
	}
}