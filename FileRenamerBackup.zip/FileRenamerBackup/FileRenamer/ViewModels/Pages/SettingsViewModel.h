﻿#pragma once

#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.UI.Xaml.Controls.h>
#include <winrt/Windows.System.h>

#include "Extensions/Command/RelayCommand.h"
#include "MileWindow.h"
#include "Models/Settings/Appearence/ThemeModel.h"
#include "Services/Controls/Settings/Appearance/ThemeService.h"
#include "SettingsViewModel.g.h"

namespace winrt
{
	namespace WinrtControls = Windows::UI::Xaml::Controls;
	namespace WinrtCollections = Windows::Foundation::Collections;
	namespace WinrtFoundation = Windows::Foundation;
	namespace WinrtInput = Windows::UI::Xaml::Input;
	namespace WinrtSystem = Windows::System;
}

namespace winrt::FileRenamer::implementation
{
	struct SettingsViewModel : SettingsViewModelT<SettingsViewModel>
	{
	public:
		SettingsViewModel();

		winrt::FileRenamer::ThemeModel Theme();
		void Theme(winrt::FileRenamer::ThemeModel const& value);

		winrt::WinrtInput::ICommand RestartCommand();
		winrt::WinrtInput::ICommand SettingsColorCommand();
		winrt::WinrtInput::ICommand ThemeSelectCommand();

		winrt::WinrtCollections::IObservableVector<winrt::FileRenamer::ThemeModel> ThemeList();

		void OnSelectionChanged(winrt::WinrtFoundation::IInspectable const& sender, winrt::WinrtControls::SelectionChangedEventArgs args);

	private:
		winrt::FileRenamer::ThemeModel _theme{ nullptr };

		winrt::WinrtInput::ICommand _restartCommand;
		winrt::WinrtInput::ICommand _settingsColorCommand;
		winrt::WinrtInput::ICommand _themeSelectCommand;

		winrt::WinrtCollections::IObservableVector<winrt::FileRenamer::ThemeModel> _themeList{ nullptr };
	};
}

namespace winrt::FileRenamer::factory_implementation
{
	struct SettingsViewModel : SettingsViewModelT<SettingsViewModel, implementation::SettingsViewModel>
	{
	};
}
