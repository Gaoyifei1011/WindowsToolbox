#include "global.h"

ConfigService AppConfigService;
NavigationService AppNavigationService;
ResourceService AppResourceService;
ThemeService AppThemeService;