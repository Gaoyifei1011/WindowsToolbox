# FileRenamer
文件重命名工具（基于 Mile.Xaml(Xaml islands)构建）

时间关系，近期内不会有太大动作，如有时间，一定开发完成
